from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import os
from pdfminer.high_level import extract_text

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

ALLOWED_EXTENSIONS = {'pdf'}

# Create upload folder if not exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text_from_pdf(filepath):
    return extract_text(filepath)

def calculate_score(resume_text):
    score = 0
    if 'experience' in resume_text.lower():
        score += 20
    if 'education' in resume_text.lower():
        score += 20
    if 'skills' in resume_text.lower():
        score += 20
    if '@' in resume_text:
        score += 10
    if 'python' in resume_text.lower():
        score += 10
    if len(resume_text.split()) > 200:
        score += 20
    return min(score, 100)

@app.route('/', methods=['GET', 'POST'])
def index():
    score = None
    snippet = ""
    if request.method == 'POST':
        if 'resume' not in request.files:
            return render_template('index.html', error="No file uploaded.")
        file = request.files['resume']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            text = extract_text_from_pdf(filepath)
            score = calculate_score(text)
            snippet = text[:500]

    return render_template('index.html', score=score, snippet=snippet)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)
