# Resume Scoring Web App

A simple Flask-based web app to score uploaded resumes based on content using PDF parsing.

## Features
- Upload PDF resume
- Extract text
- Assign a score based on presence of keywords like skills, education, etc.

## How to Run

```bash
pip install -r requirements.txt
python app.py
```

Then open `http://localhost:3000` in your browser.

## Folder Structure

- `app.py`: Main Flask app
- `templates/index.html`: HTML for UI
- `uploads/`: Auto-created folder for uploaded files
